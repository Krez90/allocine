-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 28 nov. 2018 à 13:54
-- Version du serveur :  10.1.36-MariaDB
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `allocine`
--

-- --------------------------------------------------------

--
-- Structure de la table `film`
--

CREATE TABLE `film` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date_de_sortie` date NOT NULL,
  `id_nationalite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `film`
--

INSERT INTO `film` (`id`, `titre`, `description`, `date_de_sortie`, `id_nationalite`) VALUES
(16, 'Avenger Invinity war', 'Les Avengers et leurs alliés devront être prêts à tout sacrifier pour neutraliser le redoutable Thanos avant que son attaque éclair ne conduise à la destruction complète de l’univers.', '2018-04-25', 2),
(17, 'Batman The Dark Knight', 'Dans ce nouveau volet, Batman augmente les mises dans sa guerre contre le crime. Avec l\'appui du lieutenant de police Jim Gordon et du procureur de Gotham, Harvey Dent, Batman vise à éradiquer le crime organisé qui pullule dans la ville. Leur association est très efficace mais elle sera bientôt bouleversée par le chaos déclenché par un criminel extraordinaire que les citoyens de Gotham connaissent sous le nom de Joker', '2008-08-13', 2),
(18, 'Django Unchained', 'Alors que les deux hommes pistent les dangereux criminels, Django n’oublie pas que son seul but est de retrouver Broomhilda, sa femme, dont il fut séparé à cause du commerce des esclaves…\r\n', '2013-01-16', 2),
(19, 'La Ligne Verte', 'Paul Edgecomb, pensionnaire centenaire d\'une maison de retraite, est hanté par ses souvenirs. Gardien-chef du pénitencier de Cold Mountain en 1935, il était chargé de veiller au bon déroulement des exécutions capitales en s’efforçant d\'adoucir les derniers moments des condamnés. Parmi eux se trouvait un colosse du nom de John Coffey, accusé du viol et du meurtre de deux fillettes. Intrigué par cet homme candide et timide aux dons magiques, Edgecomb va tisser avec lui des liens très forts.', '2000-03-01', 2),
(20, 'Pulp Fiction', 'L\'odyssée sanglante et burlesque de petits malfrats dans la jungle de Hollywood à travers trois histoires qui s\'entremêlent.', '1994-10-26', 2),
(21, 'Harry Potter 4 Et La Coupe De Feu', 'La quatrième année à l\'école de Poudlard est marquée par le \"Tournoi des trois sorciers\". Les participants sont choisis par la fameuse \"coupe de feu\" qui est à l\'origine d\'un scandale. Elle sélectionne Harry Potter alors qu\'il n\'a pas l\'âge légal requis !\r\n\r\nAccusé de tricherie et mis à mal par une série d\'épreuves physiques de plus en plus difficiles, ce dernier sera enfin confronté à Celui dont on ne doit pas prononcer le nom, Lord V.', '2005-11-30', 2),
(22, 'Les bronzes', 'Un groupe de vingt personnes arrive extenué dans un club situé en Afrique pour passer quelques jours de repos', '1978-11-01', 1),
(23, 'Equalizer', 'McCall, la page était tournée. Il pensait en avoir fini avec son mystérieux passé. Mais lorsqu’il fait la connaissance de Teri, une jeune fille victime de gangsters russes violents, il lui est impossible de ne pas réagir. Sa soif de justice se réveille et il sort de sa retraite pour lui venir en aide. McCall n’a pas oublié ses talents d’autrefois...', '2014-10-01', 2),
(24, 'Mission impossible', 'Ethan Hunt accompagné de son équipe de l’IMF – Impossible Mission Force et de quelques fidèles alliées sont lancés dans une course contre la montre, suite au terrible échec d’une mission', '1996-10-23', 2),
(25, 'Lords of War', 'Né en Ukraine avant l\'effondrement du bloc soviétique, Yuri arrive aux Etats-Unis avec ses parents. Il se fait passer pour un émigrant juif... Audacieux et fin négociateur, il se fait une place dans le trafic d\'armes. Les énormes sommes d\'argent qu\'il gagne lui permettent aussi de conquérir celle qui l\'a toujours fasciné, la belle Ava. Parallèlement à cette vie de mari et de père idéal, Yuri devient l\'un des plus gros vendeurs d\'armes clandestins du monde. Utilisant ses relations à l\'Est, il multiplie les coups toujours plus risqués, mais parvient chaque fois à échapper à Jack Valentine, l\'agent d\'Interpol qui le pourchasse. Des luxueux immeubles new-yorkais aux palais des dictateurs africains, Yuri joue de plus en plus gros. Convaincu de sa chance, il poursuit sa double vie explosive, jusqu\'à ce que le destin et sa conscience le rattrapent...', '2006-01-04', 2),
(26, 'La Reine des neiges', 'Anna, une jeune fille aussi audacieuse qu’optimiste, se lance dans un incroyable voyage en compagnie de Kristoff, un montagnard expérimenté, et de son fidèle renne, Sven à la recherche de sa sœur, Elsa, la Reine des Neiges qui a plongé le royaume d’Arendelle dans un hiver éternel…  En chemin, ils vont rencontrer de mystérieux trolls et un drôle de bonhomme de neige nommé Olaf, braver les conditions extrêmes des sommets escarpés et glacés, et affronter la magie qui les guette à chaque pas.', '2013-12-04', 2),
(27, 'Le nombre 23', 'Walter menait une vie paisible, jusqu\'à ce qu\'il découvre un étrange roman, Le Nombre 23. D\'abord intrigué par ce thriller, Walter s\'aperçoit rapidement qu\'il existe des parallèles troublants entre l\'intrigue et sa propre vie. Peu à peu, l\'univers du livre envahit sa réalité jusqu\'à l\'obsession. Comme Fingerling, le détective de l\'histoire, Walter est chaque jour plus fasciné par le pouvoir caché que semble détenir le nombre 23. Ce nombre est partout dans sa vie, et Walter est de plus en plus convaincu qu\'il est condamné à commettre le même meurtre que Fingerling... Des images cauchemardesques se mettent à le hanter, celles du terrible destin de sa femme et d\'un de leurs amis, Isaac French. Walter ne pourra plus échapper au mystère de ce livre. Ce n\'est qu\'en découvrant le secret du nombre 23 qu\'il aura une chance de changer son destin...', '2007-02-28', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`),
  ADD KEY `film_nationalite_FK` (`id_nationalite`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `film`
--
ALTER TABLE `film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `film_nationalite_FK` FOREIGN KEY (`id_nationalite`) REFERENCES `nationalite` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
